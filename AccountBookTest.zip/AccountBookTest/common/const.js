
const classify = [{
    id: '0',
    title: '餐饮'
}, {
    id: '1',
    title: '购物'
}, {
    id: '2',
    title: '日用'
}, {
    id: '3',
    title: '交通'
}, {
    id: '4',
    title: '服饰'
  }, {
    id: '5',
    title: '住宿'
},{
    id: '6',
    title: '旅游'
},{
  id: '7',
  title: '其他'
}];
const classifyincome = [{
  id: '0',
  title: '工资'
}, {
  id: '1',
  title: '兼职'
}, {
  id: '2',
  title: '理财'
}];

let info = {
    classify,
    classifyincome
};

export default info;