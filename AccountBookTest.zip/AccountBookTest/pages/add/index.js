import info from '../../common/const';
info.classify.unshift({ title: '哪哪儿都花钱' });
Page({
    data: {
        classifyArr: info.classify.map((item) => item.title),
        index: 0,
        date: '快想想',
        amt: null,
        saveBtnClick: false
    },
    onAmountChange(e) {
        const amt = e.detail.value;
        if (/^0/.test(amt)) {
            wx.showToast({title: '格式出错了'});
        }

        this.setData({
            amt
        });
    },
    onClassifyChange(e) {
        this.setData({
            index: e.detail.value
        })
    },
    onDateChange(e) {
        this.setData({
            date: e.detail.value
        })
    },
    saveBtn() {
        const { date, amt, index } = this.data;
        if (index === 0 && date === '快想想' && !amt) return;

        let accountArr = wx.getStorageSync('accountArr') || [];
        accountArr.push({
            date,
            expend: amt,
            id: index,
            title: info.classify[index].title,
            tag: 'outcome'
        });

        wx.setStorageSync('accountArr', accountArr);
        wx.navigateBack();
    },
    onLoad(params) {
        if(params.type == 'add'){
          return;
        }
        const {date, amt, index} = params;
        let accountArr = wx.getStorageSync('accountArr');
        // 处理修改
        accountArr.forEach((item, idx) => {
           if (item.date === date && item.expend === amt && item.id === index) {
               accountArr.splice(idx, 1);
           }
        });
        wx.setStorageSync('accountArr', accountArr);

        this.setData({
            index,
            date,
            amt
        });
    }
});