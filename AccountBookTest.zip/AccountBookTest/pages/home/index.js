import { sortArray, getExpendAmt, getIncomeAmt, clearOldData, getMonthYearDay, groupByAttr } from '../../common/util';

Page({
    data: {
        curExpendSum: 0, 
        curIncomeSum: 0,
        classify: wx.getStorageSync('accountArr') || []
    },
    modifyItem(e) {
        const data = e.currentTarget.dataset.item;
        const {date, expend, id} = data;
        wx.navigateTo({
            url: `/pages/add/index?index=${id}&date=${date}&amt=${expend}`
        })
    },
    onLoad: function (options) {
        console.log('onLoad');
    },
    onReady: function () {
        console.log('onReady');
    },

    getCurMonthExpend(data) {
        const { year, month } = getMonthYearDay();
        let curMonthDataArr = [];

        data.forEach((item) => {
           if (item.tag != 'outcome') return;
            const dateArr = item.date.split('-');
            const [curYear, curMonth] = dateArr;
            if (curYear == year && curMonth == month) {
                curMonthDataArr.push(item);
            }
        });

        this.setData({
            curExpendSum: getExpendAmt(curMonthDataArr)
        })
    },

  getCurMonthIncome(data) {
    const { year, month } = getMonthYearDay();
    let curMonthDataArr = [];

    data.forEach((item) => {
      if (item.tag != 'income') return;
      const dateArr = item.date.split('-');
      const [curYear, curMonth] = dateArr;
      if (curYear == year && curMonth == month) {
        curMonthDataArr.push(item);
      }
    });

    this.setData({
      curIncomeSum: getIncomeAmt(curMonthDataArr)
    })
  },

  getTotal(arr, tag) {
    let t = 0;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i].tag != tag) continue
      t = +arr[i].expend + t

    }
    console.log(t)
    return t
  },

  // 重组对象数组
  recombine(obj) {
    let arr = [];
    Object.keys(obj).forEach((key) => {
      arr.push({
        date: key,
        everydayExpend: this.getTotal(obj[key], 'outcome'),
        everydayIncome: this.getTotal(obj[key], 'income'),
        dataArr: obj[key]
      });
    });

    return arr;
  },
  onShow() {
    let data = wx.getStorageSync('accountArr') || [];
    let formatData = data.sort(sortArray("date"));
    const groupDataObj = groupByAttr(formatData, 'date');
    const recombineArr = this.recombine(groupDataObj);

    this.setData({
      classify: recombineArr
    });

    this.getCurMonthExpend(formatData);
    this.getCurMonthIncome(formatData);
    
    console.log('onShow');
  },
    addCount: function(){
      wx.navigateTo({
        url: '/pages/add/index?type=add',
      })
    },
  incomeCount: function () {
    wx.navigateTo({
      url: '/pages/income/index?type=add',
    })
  },
    onHide: function () {
        console.log('onHide');
    },
    onUnload: function () {
        console.log('onUnload');
    }
});